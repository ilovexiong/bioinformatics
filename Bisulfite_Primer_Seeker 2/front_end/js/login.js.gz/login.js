$(document).ready(function(){
	$(".button").button();
	$(document).on("click", ".button", function(){
		$($(this).parent()).submit();
	});
	
});