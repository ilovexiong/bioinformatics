function highlight_cpg(sequence){
	$("#cpg_track").empty();
	
	var positions = {}
	var last_cpg = -1;
	while(true){
		last_cpg = sequence.indexOf("CG", last_cpg+1);
		if(!(last_cpg in positions)){
			if(last_cpg==-1){
				break;
			}
			$("<div></div>")
			.addClass("cpg")
			.css("left", 1000*last_cpg/sequence.length)
			.appendTo($("#cpg_track"));
			
			positions[last_cpg] = true;
		}
	};
}

$(document).ready(function() {
	$("#seq").blur(function(){
		highlight_cpg($(this).val());		
	});
	
	// set result	
	var result = $.parseJSON("{\"primers\":	[{\"product_size\": 324, \"cpg_counts\": 28, \"forward\": {\"start\": 596, \"len\": 27, \"tm\": 60}, \"reverse\": {\"start\": 894, \"len\": 27, \"tm\": 56}}, {\"product_size\": 324, \"cpg_counts\": 24, \"forward\": {\"start\": 483, \"len\": 35, \"tm\": 60}, \"reverse\": {\"start\": 783, \"len\": 25, \"tm\": 60}}, {\"product_size\": 256, \"cpg_counts\": 22, \"forward\": {\"start\": 664, \"len\": 35, \"tm\": 60}, \"reverse\": {\"start\": 914, \"len\": 27, \"tm\": 56}}, {\"product_size\": 305, \"cpg_counts\": 16, \"forward\": {\"start\": 397, \"len\": 30, \"tm\": 61}, \"reverse\": {\"start\": 676, \"len\": 27, \"tm\": 56}}],\"sequence\": \"TCAGAGTCCGGCTCAGGCTCCGGCTGCGGCTCCAGCCCGCGATGCCCCATTCCGTGACCCTGCGCGGGCCTTCGCCCTGGGGCTTCCGCCTGGTGGGCGGCCGGGACTTCAGCGCGCCCCTCACCATCTCACGGGTCCATGCTGGCAGCAAGGCTGCATTGGCTGCCCTGTGCCCAGGAGACCTGATCCAGGCCATCAATGGTGAGAGCACAGAGCTCATGACACACCTGGAGGCACAGAACCGCATCAAGGGCTGCCACGATCACCTCACACTGTCTGTGAGCAGGCCTGAGGGCAGGAGCTGGCCCAGTGCCCCTGATGACAGCAAGGCTCAGGCACACAGGATCCACATCGATCCTGAGATCCAGGACGGCAGCCCAACAACCAGCAGGCGGCCCTCAGGCACCGGGACTGGGCCAGAAGATGGCAGACCAAGCCTGGGATCTCCATATGGACAACCCCCTCGCTTTCCAGTCCCTCACAATGGCAGCAGCGAGGCCACCCTGCCAGCCCAGATGAGCACCCTGCATGTGTCTCCACCCCCCAGCGCTGACCCAGCCAGAGGCCTCCCGCGGAGCCGGGACTGCAGAGTCGACCTGGGCTCCGAGGTGTACAGGATGCTGCGGGAGCCAGCCGAGCCCGTGGCCGCGGAGCCCAAGCAGTCAGGCTCCTTCCGCTACTTGCAGGGCATGCTAGAGGCCGGCGAGGGCGGGGATTGGCCCGGGCCTGGCGGCCCCCGGAACCTCAAGCCCACGGCCAGCAAGCTGGGCGCTCCGCTGAGCGGCCTGCAGGGGCTGCCCGAGTGCACGCGCTGCGGCCACGGCATCGTGGGCACCATCGTCAAGGCACGGGACAAGCTCTACCATCCCGAGTGCTTCATGTGCAGTGACTGCGGCCTGAACCTCAAGCAGCGTGGTTACTTCTTTCTGGACGAGCGGCTCTACTGTGAGAGCCACGCCAAGGCGCGCGTGAAGCCGCC\"}");

	for(var i=0; i<result.primers.length; i++){
		var design = result.primers[i];

		var forward_html = $("<div></div>").attr("id", "forward")
		.attr("start", design.forward.start)
		.attr("size", design.forward.len)
		.text("forward: start="+design.forward.start+", size="+design.forward.len+", Tm="+design.forward.tm+", sequence="+result.sequence.substring(design.forward.start, design.forward.start+design.forward.len+1));
		var reverse_html = $("<div></div>").attr("id", "reverse")
		.attr("start", design.reverse.start)
		.attr("size", design.reverse.len)
		.text("reverse: start="+design.reverse.start+", size="+design.reverse.len+", Tm="+design.reverse.tm+", sequence="+result.sequence.substring(design.reverse.start, design.reverse.start+design.reverse.len+1));
		
		var design_html = $("<div></div>").attr("id", "design"+i)
		.addClass("primers")
		.attr("start", design.reverse.start)
		.attr("size", design.reverse.len)
		.text("Product Size="+design.product_size+", Amplicon CpG="+design.cpg_counts);
		
		$(design_html)
		.append($(forward_html))
		.append($(reverse_html))
		.mouseenter(function(){
			$("#forward_img")
			.css("left", $(this).find("#forward").attr("start"))
			.css("width", $(this).find("#forward").attr("size"))	
			
			$("#reverse_img")
			.css("left", $(this).find("#reverse").attr("start"))
			.css("width", $(this).find("#reverse").attr("size"));
			
			$("#target")
			.text((parseInt($(this).find("#reverse").attr("start"))-parseInt($(this).find("#forward").attr("start"))+parseInt($(this).find("#reverse").attr("size"))-1)+"bp")
			.css("left", parseInt($(this).find("#forward").attr("start"))+parseInt($(this).find("#forward").attr("size")))
			.css("width", $(this).find("#reverse").attr("start")-$(this).find("#forward").attr("start")-$(this).find("#forward").attr("size"))		
		})
		.appendTo("#result");
	}

	var formatted_seq = "";
	for(var i=0; i<result.sequence.length/100; i++){
		formatted_seq += result.sequence.substring(i*100, (i+1)*100)+"<br>";
	}
	$("<p></p>")
	.html("input sequence<br>"+formatted_seq)
	.appendTo("#input");

	// highlight CpG
	highlight_cpg(result.sequence);
});
