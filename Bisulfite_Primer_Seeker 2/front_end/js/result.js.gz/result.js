function set_primers_loc(primer_pair, seq_len, product_size, num_of_cpgs){
	// set forward
	var f_left_offset = Math.round($("#seq_track").offset().left + parseInt($(primer_pair).find(".forward.start").text())/seq_len*$("#seq_track").width());
	var f_width = Math.round(parseInt($(primer_pair).find(".forward.primer_len").text())/seq_len*$("#seq_track").width())
	var r_left_offset = Math.round($("#seq_track").offset().left + parseInt($(primer_pair).find(".reverse.start").text())/seq_len*$("#seq_track").width());
	var r_width = Math.round(parseInt($(primer_pair).find(".reverse.primer_len").text())/seq_len*$("#seq_track").width())
	
	$("#forward_track").width(f_width);
	$("#forward_track").offset({'left': f_left_offset});
	
	$("#target_track").width(r_left_offset-f_width-f_left_offset);
	$("#target_track").offset({'left': f_left_offset+f_width});
	$("#target_track").text(product_size+"bp "+num_of_cpgs+"CpGs");
	
	$("#reverse_track").width(r_width);
	$("#reverse_track").offset({'left': r_left_offset});


}

function get_cpg_locs(seq){
	var cpg_locs = new Array();
	for(i=0; i<seq.length; i++){
		try{
			var next_nt = seq[i+1];
		}catch(err){
			var next_nt = null;
		}
		if((seq[i]=="C" || seq[i]=="c") && (next_nt=="G" || next_nt=="g")){
			cpg_locs.push(i);
		}
	}
	return cpg_locs
}

$.extend( $.fn.dataTableExt.oStdClasses, {
    "sWrapper": "dataTables_wrapper form-inline"
} );

$(document).ready(function() {
	$("#primers_table").dataTable({
		// "bJQueryUI": true
		"bFilter": false,
		"bInfo": false,
		"bPaginate": false,
		"sDom": "<<'span6'l><'span6'f>r>t<<'span6'i><'span6'p>>"
	});
	
	
	// add cpgs
	var seq = $("#seq_track").attr("alt");
	var cpg_locs = get_cpg_locs(seq);
	$.each($(cpg_locs), function(i, loc){
		var left_offset = loc/seq.length*$("#seq_track").width() + $("#seq_track").offset().left;
		$("<div class='cpg'></div>").width(2)
									.height($("#seq_track").height())
									.offset({'left': left_offset})
									.appendTo("#seq_track");
	});
	
	$(document).on("mouseover", ".primer", function(){
		var product_size = parseInt($(this).find(".amp_seq_len").text());
		var num_of_cpgs = parseInt($(this).find(".cpg_num").text());
		set_primers_loc($(this), seq.length, product_size, num_of_cpgs);
	});
});