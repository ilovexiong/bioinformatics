$.extend( $.fn.dataTableExt.oStdClasses, {
    "sWrapper": "dataTables_wrapper form-inline"
} );

$(document).ready(function() {
	// $('#design_table tr').click(function(){
	//         $(this).toggleClass('row_selected');
	//     });
		
	$("#design_table").dataTable({
		"sPaginationType": "full_numbers",
		"bFilter": false,
		"bPaginate": false,
		"bInfo": false,
		"sDom": "<<'span6'l><'span6'f>r>t<<'span6'i><'span6'p>>"
	});
	
	$(document).on("click", ".show_seq", function(){
		var seq = $(this).attr("alt");
		$("<div class='sequence'>"+seq+"</div>").dialog({
			width: "80%",
			title: "Sequence"
		});
	});
	
	$(document).on("click", ".show_params", function(){
		$.ajax("/tools/get_params/"+$(this).parent().attr("alt")+"/")
		.done(function(data){
			var params = "";
			$.each(data, function(i, v){
				params += "<tr><td>"+i+"</td><td>"+v+"</td></tr>";
			});
			$("<table>"+params+"</table>").dialog({
				close: function(){
					$(this).dialog('destroy').remove()
				},
				title: "Parameters"
			});
		});
	});
	
	$(document).on("click", ".design_list_folder", function(){
		window.location = "/tools/design_list/"+$(this).text()+"/";
	});
});