function highlight_cpg(sequence){
	jQuery("#cpg_track").empty();
	
	var positions = {}
	var last_cpg = -1;
	while(true){
		last_cpg = sequence.toUpperCase().indexOf("CG", last_cpg+1);
		if(!(last_cpg in positions)){
			if(last_cpg==-1){
				break;
			}
			jQuery("<div></div>")
			.addClass("cpg")
			.css("left", jQuery("#seq_img").width()*last_cpg/sequence.length+jQuery("#seq_img").position().left)
			.css("top", jQuery("#seq_img").position().top)
			.appendTo(jQuery("#cpg_track"));
			
			positions[last_cpg] = true;
		}
	};
	jQuery(".cpg").width(jQuery("#seq_img").width()*2/sequence.length);
}