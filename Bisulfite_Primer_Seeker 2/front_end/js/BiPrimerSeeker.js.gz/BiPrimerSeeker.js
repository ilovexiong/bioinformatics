function getCookie(c_name){
	var i,x,y,ARRcookies=document.cookie.split(";");
	for (i=0;i<ARRcookies.length;i++){
	  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
	  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
	  x=x.replace(/^\s+|\s+jQuery/g,"");
	  if (x==c_name){
	    return unescape(y);
		}
  	}
}

function get_bs_cov_seq(seq){
	bs_seq = "";
	for(var i=0; i<seq.length; i++){
		if(seq[i]=="C"){
			if(seq[i+1]=="G"){
				bs_seq += "C";
			}else{
				bs_seq += "T";
			}
		}else{
			bs_seq += seq[i];
		}
	}
	return bs_seq;
}

function get_rc_seq(seq){
	var comp_map = {
			"A": "T",
			"T": "A",
			"C": "G",
			"G": "C",
	};
	rc_seq = "";
	
	for(var i=seq.length-1; i>=0; i--){
		rc_seq += comp_map[seq[i]]
	}
	return rc_seq;
}
	
function setCookie(c_name,value,exdays){
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}

function checkCookie(){
var username=getCookie("username");
if (username!=null && username!=""){
  alert("Welcome again " + username);
  }
else{
  username=prompt("Please enter your name:","");
  if (username!=null && username!=""){
    setCookie("username",username,365);
    }
  }
}
function deleteAllCookies() {
    var cookies = document.cookie.split(";");

    for (var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        var eqPos = cookie.indexOf("=");
        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
    }
}

function set_email_value(){
	var email = getCookie("email");
	if ((!email)||(email=='null')){
		email = "";
	}
	document.getElementById("email").value = email;
}

function save_email(){
	var email = document.getElementById("email").value;
	setCookie("email", email, 60);
}

function get_seq(){
	var lines = "";
	var lines_old = document.getElementById("seq").value.split("\n");
	for(var i=0; i<lines_old.length; i++){
		if(lines_old[i][0]!=">"){
			lines += lines_old[i].toUpperCase().replace(/[^A,T,G,C,R,Y,N,W,S,M,K,B,H,D,V]+/g, "").replace(/[R,Y,N,W,S,M,K,B,H,D,V]+/g, "N");
		}
	}	
	return lines;
}

function seq_count(){
	seq_str = get_seq();
	var seq_count = seq_str.length;
	if(seq_count>1000){
		document.getElementById("seq_count").innerHTML = "<span style='background-color: red'>"+seq_count+"</span> bp";
	}else{
		document.getElementById("seq_count").innerHTML = seq_count+" bp";
	}
}

function get_formattedCells(seq){
	var col_per_row = 100;
	var nts = new Array();
	
	var row_num = seq.length/col_per_row;
	if(row_num%col_per_row>0){
		row_num += 1;
	}
	
	var isLastC = false;
	for(var i=0; i<seq.length; i++){
		var col_indx = parseInt(i/col_per_row);
		if(nts[col_indx]==undefined){
			nts[col_indx] = "";
		}
		var nt = seq[i].toUpperCase();			
		if(i+1<seq.length && seq[i+1].toUpperCase()=="G" && nt=="C"){
			nts[col_indx] += "<span class='cpg_color'>"+nt+"</span>";
			isLastC = true;
		}else{
			if(isLastC){
				nts[col_indx] += "<span class='cpg_color'>"+nt+"</span>";
				isLastC = false;
			}else{
				nts[col_indx] += nt;
			}
		}
	}
	
	return nts;
}

function change_color(element){
	if(element.style.backgroundColor==""){
		element.style.backgroundColor = "pink";
	}else{
		element.style.backgroundColor = "";
	}
	
} 

//function addFormattedSeq(seq){
//	if(jQuery("#bs_conv_check").attr("checked")){
//		seq = get_bs_cov_seq(seq)
//	}
//	if(jQuery("#rc_check").attr("checked")){
//		seq = get_rc_seq(seq)
//	}
//	
//	var formatted_seq = document.getElementById("formatted_seq");
//	var formatted_seq_innerHTML = "<table style='margin: auto;'>";
//	var cells = get_formattedCells(seq);
//	for(var i=0; i<cells.length; i++){
//		formatted_seq_innerHTML += "<tr style='font-family: courier new; font-size: 14px'><td class='line_num seq_preview'>"+(parseInt(i)*100+1)+"</td><td class='seq_preview'>"+cells[i]+"</td></tr>";
//	}
//
//	formatted_seq_innerHTML += "</table>";
//	formatted_seq.innerHTML = formatted_seq_innerHTML;
//	
//}

function addFormattedSeq(seq){
	jQuery("#formatted_seq").empty();
	
	if(jQuery("#bs_conv_check").attr("checked")){
		seq = get_bs_cov_seq(seq)
	}
	if(jQuery("#rc_check").attr("checked")){
		seq = get_rc_seq(seq)
	}

	var formatted_seq_array = get_formattedCells(seq);
	var line_num_html = "";
	var seq_html = "";
	for(var i=0; i<formatted_seq_array.length; i++){
		line_num_html += (i*100+1)+"<br>";
		seq_html += formatted_seq_array[i]+"<br>";
	}
	jQuery("<table><tr>" +
			"<td class='line_num seq_preview'>"+line_num_html+"</td>" +
			"<td class='seq_preview'>"+seq_html+"</td>" +
	"</tr></table>").appendTo("#formatted_seq");
}

function sequence_preview(){
	var seq = get_seq();
	addFormattedSeq(seq); 
	seq_count();
	highlight_cpg(seq);
}

function set_seq_value(){
	var seq_str = get_seq();
	if(seq_str.length>1000){
		alert("The input sequence is larger than 1kb");
		return false;
	}else if(seq_str.length<50){
		alert("The input sequence is smaller than 50bp");
                return false;
	}else{
		document.getElementById("seq").value = seq_str;
		return true;
	}
}

function tutorial(){
	jQuery(".tutorial").remove();
	var seq_tutorial = jQuery("<div id='seq_tutorial' class='tutorial' style='position: absolute' exTop='200' exLeft='200'>"+
			"The sequence can be fasta format or just DNA sequence or with line number in front of each line<br>(no conversion necessary).</div>").offset({top: jQuery("#seqDiv").offset().top+100, left: jQuery("#seqDiv").offset().left+200});
	var preview_tutorial = jQuery("<div id='preview_tutorial' class='tutorial' style='position: absolute' exTop='430' exleft='450'>This highlights CpGs.</div>").offset({top: jQuery("#previewDiv").offset().top+150, left: jQuery("#previewDiv").offset().left+350});
	var parameter_tutorial = jQuery("<div id='preview_tutorial' class='tutorial' style='position: absolute' exTop='200' exleft='950'>This default paramters are recommended. please  fill in your email address, so that the primer designs can be sent directly to your inbox.</div>").offset({top: jQuery("#paramDiv").offset().top+170, left: jQuery("#paramDiv").offset().left+10});
	jQuery("#seqDiv").prepend(seq_tutorial);
	jQuery("body").prepend(preview_tutorial);
	jQuery("body").prepend(parameter_tutorial);
}

function set_parameter(param, value){
	if(value!=null){
		jQuery("#"+param).val(value);
	}
}

jQuery(document).ready(function() {
	set_parameter("email", getCookie("email"))
	set_parameter("minPrimerLen", getCookie("minPrimerLen"))
	set_parameter("maxPrimerLen", getCookie("maxPrimerLen"))
	set_parameter("minPdtLen", getCookie("minPdtLen"))
	set_parameter("maxPdtLen", getCookie("maxPdtLen"))
	set_parameter("lowTm", getCookie("lowTm"))
	set_parameter("highTm", getCookie("highTm"))

 	if(getCookie("visited")==null){
 		tutorial();
 		jQuery("#desc_toggle").hide();
 		setCookie("visited", "yes", 3650);
 	}else{
 		jQuery("#seq").focus();
 		jQuery("#desc").hide();
 		jQuery("#desc_toggle").text("show the description");
 	}
	
	jQuery(".tutorial").live("click", function(){
		jQuery(this).hide();
	});
	
	jQuery("#seq").click(function(){
		jQuery("#seq_tutorial").hide();
	});
	
	jQuery("#form1").validate({
		 submitHandler: function(form) {
			   return set_seq_value() && form.submit();
			 }
	});
	
	jQuery("#form1").submit(function(){
		setCookie("minPrimerLen", jQuery("#minPrimerLen").val(), 3650);
		setCookie("maxPrimerLen", jQuery("#maxPrimerLen").val(), 3650);
		setCookie("minPdtLen", jQuery("#minPdtLen").val(), 3650);
		setCookie("maxPdtLen", jQuery("#maxPdtLen").val(), 3650);
		setCookie("lowTm", jQuery("#lowTm").val(), 3650);
		setCookie("highTm", jQuery("#highTm").val(), 3650);
		setCookie("email", jQuery("#email").val(), 3650);

	});

	jQuery(window).resize(function(){
		if(getCookie("visited")==null){
			tutorial();
		}
	});

	jQuery("#desc_toggle").click(function(){
		if(jQuery("#desc").is(":visible")){
			jQuery("#desc").hide();
			jQuery(this).text("show the description");
                }else{
	                jQuery("#desc").show();
        	        jQuery(this).text("hide");
		}		
	});
	
	jQuery("#seq")
	.change(function(){
		sequence_preview();
	})
	.keyup(function(){
		sequence_preview();
	})
	.mouseup(function(){
		sequence_preview();
	})
	.focus();
	
	jQuery("#line_num_check").change(function(){
		if(jQuery(this).attr("checked")){
			jQuery(".line_num").show();
			
		}else{
			jQuery(".line_num").hide();
		}
	});
	
	jQuery("#bs_conv_check").change(function(){
		addFormattedSeq(get_seq());
		if(jQuery("#line_num_check").attr("checked")){
			jQuery(".line_num").show();
			
		}else{
			jQuery(".line_num").hide();
		}
	});
	jQuery("#rc_check").change(function(){
		addFormattedSeq(get_seq());
		if(jQuery("#line_num_check").attr("checked")){
			jQuery(".line_num").show();
			
		}else{
			jQuery(".line_num").hide();
		}
	});
});
