# Create your views here.
from tools.models import Bisulfite_primer_design
from django.http import HttpResponse
from django.shortcuts import render_to_response, render
from django.core.context_processors import csrf
import random
import string
import json


## need to change the path to exe_counts to default
def run_bisulfite_primer_design(request, max_exe_counts=5):    
    from django.utils import timezone
    
    bpd = Bisulfite_primer_design(
                highTm=request.POST["highTm"], 
                lowTm=request.POST["lowTm"],
                maxDiff=100, 
                seq=request.POST["inputSeq"], 
                maxPdtLen=request.POST["maxPdtLen"], 
                minPdtLen=request.POST["minPdtLen"],
                minPrimerLen=request.POST["minPrimerLen"], 
                maxPrimerLen=request.POST["maxPrimerLen"],
                allow_cpg_in_primer=request.POST["allow_cpg_in_primer"],
                email=request.POST["email"], 
                ip=request.META["REMOTE_ADDR"], 
                name='Bisulfite Primer Seeker',
                start_time=timezone.now(),
                job_name=request.POST["job_name"],
                rand_str=''.join(random.choice(string.ascii_uppercase + string.digits) for i in range(32))
        )
    bpd.get_city_country()

    if bpd.is_validated():
        from bpd_tasks import run_bisulfite_primer_seeker

        bpd.save()
        
        run_bisulfite_primer_seeker.delay(bpd)
        message = "ok"
    else:
        message = "failed"
    
    return HttpResponse(message)
    
def result(request, id_rand_str):
    bpd_id, rand_str = id_rand_str.split("_")
    try:
        bpd = Bisulfite_primer_design.objects.filter(pk=int(bpd_id)).filter(rand_str=rand_str).get()
    except:
        bpd = None
    return render_to_response("front_end/result.html", {'bpd': bpd})

def design_list(request, folder_name):
    bpds = Bisulfite_primer_design.objects.all()
    folder_names = {bpd.folder_name for bpd in bpds}
    
    if folder_name!="All":
        bpds = filter(lambda bpd: bpd.folder_name==folder_name, bpds)
    
    c = {
        'bpds': bpds,
        'folder_names': folder_names,
    }
    
    return render_to_response("front_end/design_list.html", c)
    
def get_params(request, id_rand_str):
    id, rand_str = id_rand_str.split("_")
    bpd = Bisulfite_primer_design.objects.filter(rand_str=rand_str).get(pk=id)
    params = {
        "Max Tm": bpd.highTm,
        "Min Tm": bpd.lowTm,     
        # "maxDiff": bpd.maxDiff, 
        "Max Product Length": bpd.maxPdtLen,
        "Min Product Length": bpd.minPdtLen,
        "Max Primer Length": bpd.maxPrimerLen,
        "Min Primer Length": bpd.minPrimerLen,
        "Allow CpG in Primer": bpd.allow_cpg_in_primer,
    }
    
    ## response json. how?!
    return HttpResponse(json.dumps(params), content_type="application/json")
    
#def set_folder(request, folder, id_rand_str):
    
def login(request):
    c = {
        
    }
    return render(request, "front_end/login.html")

def test(request):
    c = {'user': request.user}
    c.update(csrf(request))
    return render_to_response("front_end/test.html", c)