from celery import Celery
import subprocess, os
from django.shortcuts import render_to_response
from tools.models import Primer_pair
from django.utils import timezone

celery = Celery('tasks', broker='sqs://')

def parse_result_file(fh, bpd):
    [fh.readline() for i in range(5)]
    
    for i, line in enumerate(fh):
        if i%3==0:
            primer_pair = Primer_pair()
            eles = line.split()
            primer_pair.forward_start = int(eles[2])
            primer_pair.forward_end = int(eles[3])+1
            primer_pair.forward_tm = float(eles[6])
        elif i%3==1:
            eles = line.split()
            primer_pair.reverse_start = len(bpd.seq)-int(eles[3])
            primer_pair.reverse_end = len(bpd.seq)-int(eles[2])-1
            primer_pair.reverse_tm = float(eles[6])
            primer_pair.bisulfite_primer_design = bpd
            primer_pair.save()

@celery.task
def run_bisulfite_primer_seeker(bpd):
    '''
    run primer design
    save results to DB
    send notification email
    '''
    import tempfile
    from django.core.mail import EmailMultiAlternatives

    
    with tempfile.NamedTemporaryFile() as fw_in, tempfile.NamedTemporaryFile() as fw_out:
        fw_in.write(bpd.seq)
        fw_in.flush()
    
        ## run the program
        try:
            cmd = (os.path.join("/".join(os.path.realpath(__file__).split("/")[:-1]), "../primer_design/", "bisulfitePCR_primer_design.pl"), 
                                    "--minPrimerLen=%s"%(bpd.minPrimerLen),
                                    "--maxPrimerLen=%s"%(bpd.maxPrimerLen),
                                    "--minPdtLen=%s"%(bpd.minPdtLen),
                                    "--maxPdtLen=%s"%(bpd.maxPdtLen),
                                    "--lowTm=%s"%(bpd.lowTm),
                                    "--highTm=%s"%(bpd.highTm),
                                    "--maxTmDiff=%s"%(bpd.maxDiff),
                                    "--infile=%s"%(fw_in.name),
                                    "--outfile=%s"%(fw_out.name),
                                    "--allow_cpg_in_primer=%s"%(bpd.allow_cpg_in_primer))
            subprocess.check_output(cmd)
            
            parse_result_file(fw_out, bpd)
            bpd.isSuccessful = True
        except:
            message = "failed"
            bpd.isSuccessful = False
            raise
        bpd.end_time = timezone.now()
        bpd.save()
    
    ## send email
    # msg = EmailMultiAlternatives(
    #                             "%s (%s)"%(bpd.name, bpd.job_name), 
    #                             message, 
    #                             "services@zymoresearch.com", 
    #                             [bpd.email])
#    msg.attach_alternative(render_to_response('', {'result': bpd.primer_design_result}).content, "text/html")
    # msg.send()

    