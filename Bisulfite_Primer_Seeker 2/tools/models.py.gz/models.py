from django.db import models

class Bisulfite_primer_design(models.Model):
    from django.contrib.auth.models import User
    
    seq_name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField(null=True)
    isSuccessful = models.BooleanField()
    saw_time = models.DateTimeField(null=True)
    notified_time = models.DateTimeField(null=True)
    
    ip = models.GenericIPAddressField()
    city = models.CharField(max_length=255, null=True)
    country = models.CharField(max_length=255, null=True)
    
    ## seqeunce and parameters
    seq = models.TextField()
    highTm = models.PositiveIntegerField()
    lowTm = models.PositiveIntegerField()
    maxDiff = models.PositiveIntegerField()
    maxPdtLen = models.PositiveIntegerField()
    minPdtLen = models.PositiveIntegerField()
    maxPrimerLen = models.PositiveIntegerField()
    minPrimerLen = models.PositiveIntegerField()
    allow_cpg_in_primer = models.PositiveIntegerField()
    
    accession = models.CharField(max_length=45, null=True)
    organism = models.CharField(max_length=255, null=True)
    rand_str = models.CharField(max_length=32)
    folder_name = models.CharField(max_length=100, null=True)
    
    validated_users = models.ManyToManyField(User)


    def is_validated(self):
        ## check if sequence is all Alphabet. (prevent SQL injection and other attacks)
        if any( map(lambda x: not x.isalpha(), self.seq) ):
            return False
        return True
    
    def get_link_str(self):
        return "%s_%s"%(self.id, self.rand_str)
        
    def get_city_country(self):
        from django.contrib.gis.geoip import GeoIP
        
        if self.ip:
            g = GeoIP()
            info = g.city(self.ip)
            if info:
                self.city = info["city"]
                self.country = info["country_name"]

class Primer_pair(models.Model):
    forward_start = models.IntegerField()
    forward_end = models.IntegerField()
    forward_tm = models.FloatField()
    
    reverse_start = models.IntegerField()
    reverse_end = models.IntegerField()
    reverse_tm = models.FloatField()
    
    bisulfite_primer_design = models.ForeignKey(Bisulfite_primer_design)
    is_favorite = models.BooleanField()
    
    def get_amplicon_seq(self):
        import utils
        seq = self.bisulfite_primer_design.seq[self.forward_start:self.reverse_end]
        return utils.get_bs_seq(seq)
    
    def get_forward_seq(self):
        import utils
        seq = self.bisulfite_primer_design.seq[self.forward_start:self.forward_end]
        return utils.get_bs_seq(seq)
    
    def get_reverse_seq(self):
        import utils
        from Bio.Seq import Seq
        
        seq = self.bisulfite_primer_design.seq[self.reverse_start:self.reverse_end]
        seq = utils.get_bs_seq(seq)
        rc_seq = str(Seq(seq).reverse_complement())
        return rc_seq
        
    def get_tm_diff(self):
        return abs(self.forward_tm-self.reverse_tm)

    def get_amplicon_cpg_num(self):
        return self.get_amplicon_seq().count('CG')
        



