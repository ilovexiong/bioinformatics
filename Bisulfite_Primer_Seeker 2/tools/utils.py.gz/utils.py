
def get_bs_seq(seq):
    bs_seq = ""
    
    for i, nt in enumerate(seq):
        try:
            next_nt = seq[i+1]
        except IndexError:
            next_nt = None
            
        if nt in ('C', 'c') and next_nt not in ('G', 'g'):
            if nt.isupper():
                bs_seq += 'T'
            else:
                bs_seq += 't'
        else:
            bs_seq += nt
    return bs_seq    