from django.conf.urls import patterns, include, url

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('tools.views',
    # Examples:
    # url(r'^$', 'EpiResources_py.views.home', name='home'),
    # url(r'^EpiResources_py/', include('EpiResources_py.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
    url(r'^tools/test/$', 'test'),
    url(r'^tools/run_bisulfite_primer_design/$', 'run_bisulfite_primer_design'),
    url(r'^tools/result/(?P<id_rand_str>\w+)/$', 'result'),
    url(r'^tools/design_list/(?P<folder_name>\w+)/$', 'design_list'),
    url(r'^login/$', 'login'),
    url(r'', include('social_auth.urls')),
    url(r'^tools/get_params/(?P<id_rand_str>\w+)/$', 'get_params'),
)
