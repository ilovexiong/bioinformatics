#! /usr/bin/perl -w
use strict;
use Getopt::Long;

use XML::Writer;
use IO::File;
use Time::HiRes;

#Example usage : bisulfitePCR_primer_design_vs2.pl --minPrimerLen=29 --maxPrimerLen=35 --minPdtLen=200 --maxPdtLen=400 --lowTm=55 --highTm=61 --maxTmDiff=3 --infile="sampleseq2.txt" --outfile="output.txt" --outputXML="output.xml"
# This code contains modified Tm calculations

#Default values
my $min_primer_length = 24;
my $max_primer_length = 38;
my $min_product_length = 100;
my $max_product_length = 350;
my $lower_Tm = 55;
my $upper_Tm = 66;
my $max_Tm_difference = 2; #Maximum difference of Tm between primer pairs.
my $infile = "sampleseq2.txt";
my $outfile="output.txt";
my $output_xml = "output.xml";

## mod by hunter
## allow CpG in primer 
my $allow_cpg_in_primer = 1;

## mod by hunter
GetOptions ("minPrimerLen=i" => \$min_primer_length, # numeric   
						"maxPrimerLen=i" => \$max_primer_length,
						"minPdtLen=i" => \$min_product_length,
						"maxPdtLen=i" => \$max_product_length,
						"lowTm=f" => \$lower_Tm,              #float
						"highTm=f" => \$upper_Tm,
						"maxTmDiff=i" => \$max_Tm_difference,
            "infile=s"   => \$infile,             # string
            "outfile=s" => \$outfile,
            "outputXML=s" => \$output_xml, 
            "allow_cpg_in_primer=i" => \$allow_cpg_in_primer) || die "Incorrect usage of options\n";

open(INFILE, "$infile") || die "cannot open infile\n";
open(OUTFILE, ">$outfile") || die "cannot open outfile\n";

my $output = new IO::File(">$output_xml");
my $writer = new XML::Writer(OUTPUT => $output, DATA_MODE => 1, DATA_INDENT=>4);

my $salt_conc = 0.05;
my $primer_conc = 0.25 * (10 ** -6);
my $max_base_complements = 3;
my $primer_length;
my $optimum_product_size;
 
#Reading sequence into an array seq. 
my @seq = ();
while(my $line = <INFILE>)
{
	next if $line =~ /^>/;
	chomp $line;
 	
	$line =~ s/\s+//g;
 	$line =~ tr/[a-z]/[A-Z]/;
 	$line =~ s/U/T/g;
 	my @line = split("", $line);
 	push(@seq, @line);	
}
my $length_seq = $#seq + 1;
print OUTFILE "Length of sequence : $length_seq\n";

# Modify the sequence by converting all non-CpG C's into T's.
  
my @mod_seq = @seq;
 
for(my $i=0; $i <= $#seq; $i++)
{
	if ($seq[$i] eq "C")
 	{
 		if($i == $#seq)
 		{
 			$mod_seq[$i] = "T";
 		}
 		elsif($seq[$i+1] ne "G")
 		{
 			$mod_seq[$i] = "T";
 		}
 	}
}

my @fwd_array_num_cpg = ();
my $num_cpg = 0;
$fwd_array_num_cpg[0] = 0;

for(my $i=0; $i<$#mod_seq; $i++)
{
	$num_cpg++ if(($mod_seq[$i] eq "C") && ($mod_seq[$i+1] eq "G"));
	$fwd_array_num_cpg[$i+1] = $num_cpg;
}
 	
# Taking reverse complement of modified sequence

my @rev_comp_seq = @mod_seq;
my $rev_comp = join("", @rev_comp_seq);

$rev_comp = reverse($rev_comp);
$rev_comp =~ tr/ACTG/TGAC/;

@rev_comp_seq = split("", $rev_comp);

my @rev_array_num_cpg = ();
$num_cpg = 0;
$rev_array_num_cpg[0] = 0;

for(my $i=0; $i<$#rev_comp_seq; $i++)
{
	$num_cpg++ if(($rev_comp_seq[$i] eq "C") && ($rev_comp_seq[$i+1] eq "G"));
	$rev_array_num_cpg[$i+1] = $num_cpg;
}

my $avg_primer_length = 0;
my $count_primer_length = 0;
my %forward_primers = ();
my %reverse_primers = ();

for(my $i=$min_primer_length; $i<=$max_primer_length; $i++)
{
	$count_primer_length++;
	$avg_primer_length += $i;
	
	&pickSubstrings("fwd", \@mod_seq, $i, \%forward_primers);
	&pickSubstrings("rev", \@rev_comp_seq, $i, \%reverse_primers);
}

$avg_primer_length = $avg_primer_length/$count_primer_length;

my %fwd_product;
my %rev_product;
my %primer_pairs;
my %final_primer_pairs;
my @aoa_primer_values = (); 


for($optimum_product_size=$min_product_length; $optimum_product_size <= $max_product_length; $optimum_product_size++)
{
	%fwd_product = ();
	%rev_product = ();
 
	%primer_pairs = ();
	%final_primer_pairs = ();

	# checkProduct subroutine - extends the primers to desired product length and check for number of CpG's in product.
	&checkProduct("fwd",\%forward_primers, \@mod_seq, \%fwd_product);
	&checkProduct("rev",\%reverse_primers, \@rev_comp_seq, \%rev_product);	

	# checkOverlap subroutine - checks to see if the products of fwd and rev primers overlap
	&checkOverlap(\%fwd_product, \%rev_product, \%forward_primers, \%reverse_primers, \%primer_pairs);

	foreach my $key(sort keys %primer_pairs)
	{
		for(my $j=0; $j<=$#{$primer_pairs{$key}}; $j++)
		{
			my ($fwd_primer_start, $fwd_primer_end, $fwd_primer, $fwd_primer_Tm, $fwd_pdt_cpg) = @{${${$primer_pairs{$key}}[$j]}[0]};
			my ($rev_primer_start, $rev_primer_end, $rev_primer, $rev_primer_Tm, $rev_pdt_cpg) = @{${${$primer_pairs{$key}}[$j]}[1]};
			
			my $fwd_primer_value = &checkSelfAnnealing($fwd_primer);
			my $rev_primer_value = &checkSelfAnnealing($rev_primer);
	 						
			my $edited_fwd_primer = $fwd_primer;
			my $edited_rev_primer = $rev_primer;
 				
			if(($fwd_primer_value == 1) && ($rev_primer_value == 1))
			{
				$edited_fwd_primer =~ s/CG/YG/ ;
 				$edited_rev_primer =~ s/CG/CR/ ;
 				$edited_rev_primer =~ s/^G/R/;
 				$edited_rev_primer =~ s/G/R/;

				my @fwd_values = ($fwd_primer_start, $fwd_primer_end, $edited_fwd_primer, $fwd_primer_Tm, $fwd_pdt_cpg);
				my @rev_values = ($rev_primer_start, $rev_primer_end, $edited_rev_primer, $rev_primer_Tm, $rev_pdt_cpg);
 										
				my @primers = (\@fwd_values, \@rev_values);
				push(@{$final_primer_pairs{$key}}, \@primers);
			}
		}
	}	
	
	my %non_redundant_primer_pairs = (); 
 	
 	&pickNonRedundantPrimers(\%final_primer_pairs, \%non_redundant_primer_pairs);
 	
 	foreach my $key(sort keys %non_redundant_primer_pairs)
	{
		foreach my $array_ref(@{$non_redundant_primer_pairs{$key}})
		{		
			my @primer_values = ();
		 		
			$primer_values[0] = ${$array_ref->[0]}[0];
			$primer_values[1] = ${$array_ref->[0]}[1]; 
			$primer_values[2] = ${$array_ref->[0]}[4]; 
			$primer_values[3] = ${$array_ref->[0]}[3]; 
			$primer_values[4] = ${$array_ref->[0]}[2]; 
	 			
			$primer_values[5] = ${$array_ref->[1]}[0];
			$primer_values[6] = ${$array_ref->[1]}[1]; 
			$primer_values[7] = ${$array_ref->[1]}[4]; 
			$primer_values[8] = ${$array_ref->[1]}[3]; 
			$primer_values[9] = ${$array_ref->[1]}[2]; 
			
			$primer_values[10] = $optimum_product_size; 
			$primer_values[11] = 1;											
			
	 	  push(@aoa_primer_values, \@primer_values);
	 	}		
	}
}

my @sorted_aoa_primer_values = sort {$b->[2] <=> $a->[2]}(@aoa_primer_values); #sorting according to product CpG's

my $distance  = int($avg_primer_length/2);

for(my $i=0; $i <= $#sorted_aoa_primer_values; $i++)
{
	my $fwd_start = $sorted_aoa_primer_values[$i]->[0];
	if($sorted_aoa_primer_values[$i]->[11] != 0)
	{
		for(my $j=$i+1; $j<= $#sorted_aoa_primer_values; $j++)
		{
			if($sorted_aoa_primer_values[$j]->[11] != 0)
			{
				my $next_start = $sorted_aoa_primer_values[$j]->[0];
				if(($fwd_start-$next_start!=0) && (abs($fwd_start-$next_start)<$distance))
				{
					if($sorted_aoa_primer_values[$i]->[10] > $sorted_aoa_primer_values[$j]->[10])
					{
						$sorted_aoa_primer_values[$j]->[11] = 0;
					}
					else
					{
						$sorted_aoa_primer_values[$i]->[11] = 0;
					}
				}	
			}
		}
	}	
}	

for(my $i=0; $i <= $#sorted_aoa_primer_values; $i++)
{
	if($sorted_aoa_primer_values[$i]->[11] == 1)
	{
		my $fwd_start = $sorted_aoa_primer_values[$i]->[0];
		for(my $j=$i+1; $j<= $#sorted_aoa_primer_values; $j++)
		{
			if($sorted_aoa_primer_values[$j]->[11] == 1)
			{
				my $next_start = $sorted_aoa_primer_values[$j]->[0];
				if($fwd_start-$next_start==0)
				{
					if($sorted_aoa_primer_values[$i]->[10] > $sorted_aoa_primer_values[$j]->[10])
					{
						$sorted_aoa_primer_values[$j]->[11] = 0;
					}
					else
					{
						$sorted_aoa_primer_values[$i]->[11] = 0;
					}
					if($sorted_aoa_primer_values[$i]->[10] == $sorted_aoa_primer_values[$j]->[10])
					{
						if(($sorted_aoa_primer_values[$i]->[1] - $sorted_aoa_primer_values[$i]->[0]) >= ($sorted_aoa_primer_values[$j]->[1] - $sorted_aoa_primer_values[$j]->[0]) && ($sorted_aoa_primer_values[$i]->[6] - $sorted_aoa_primer_values[$i]->[5]) >= ($sorted_aoa_primer_values[$j]->[6] - $sorted_aoa_primer_values[$j]->[5]))
						{
							$sorted_aoa_primer_values[$j]->[11] = 0;
						}
						else
						{
							$sorted_aoa_primer_values[$i]->[11] = 0;
						}
					}
				}
			}
		}
	}
}	
	
my $num_primer_pairs = 0;
foreach my $array_ref(@sorted_aoa_primer_values)
{
	if($$array_ref[11] == 1)
	{
		$num_primer_pairs++;
	}	
}

print OUTFILE "Total of $num_primer_pairs predicted primers, sorted according to number of amplicon CpG's at :\n";
#print OUTFILE "Tm range: $lower_Tm-$upper_Tm, with max Tm difference: $max_Tm_difference\n\n";
print OUTFILE "Tm range: $lower_Tm-$upper_Tm\n\n";
		 

printf OUTFILE '%-10s %-10s %-15s %-15s %-16s %-15s %-20s %-8s', "Primer", "Length", "Start point", "End point", "Amplicon CpGs", "Product size", "Tm", "Sequence(5'->3')" . "\n";

$writer->startTag('PrimerTable');

foreach my $array_ref(@sorted_aoa_primer_values)
{
	if($$array_ref[11] == 1)
	{
		my $fwd_primer_length = ($$array_ref[1] - $$array_ref[0]) + 1;
		my $rev_primer_length = ($$array_ref[6] - $$array_ref[5]) + 1;	
		
		$writer->startTag('PrimerPair');
		$writer->startTag('Primer="Forward"');
		$writer->startTag('Length');
		$writer->characters($fwd_primer_length);
		$writer->endTag();
		$writer->startTag('StartPoint');
		$writer->characters($$array_ref[0]);
		$writer->endTag();
		$writer->startTag('EndPoint');
		$writer->characters($$array_ref[1]);
		$writer->endTag();
		$writer->startTag('AmpliconCpGs');
		$writer->characters($$array_ref[2]);
		$writer->endTag();
		$writer->startTag('ProductSize');
		$writer->characters($$array_ref[10]);
		$writer->endTag();
		$writer->startTag('Tm');
#		$writer->characters($$array_ref[3]);
		$writer->characters(printf("%.1f", $$array_ref[3]));
		$writer->endTag();
		$writer->startTag('Sequence');
		$writer->characters($$array_ref[4]);
		$writer->endTag();
		$writer->endTag();
		
		$writer->startTag('Primer= "Reverse"');
		$writer->startTag('Length');
		$writer->characters($rev_primer_length);
		$writer->endTag();
		$writer->startTag('StartPoint');
		$writer->characters($$array_ref[5]);
		$writer->endTag();
		$writer->startTag('EndPoint');
		$writer->characters($$array_ref[6]);
		$writer->endTag();
		$writer->startTag('AmpliconCpGs');
		$writer->characters($$array_ref[7]);
		$writer->endTag();
		$writer->startTag('ProductSize');
		$writer->characters($$array_ref[10]);
		$writer->endTag();
		$writer->startTag('Tm');
		$writer->characters($$array_ref[8]);
		$writer->endTag();
		$writer->startTag('Sequence');
		$writer->characters($$array_ref[9]);
		$writer->endTag();
		$writer->endTag();
		
		$writer->endTag();
				
		printf OUTFILE '%-10s %-10s %-15s %-15s %-16s %-15s %.1f %-8s', "Forward", $fwd_primer_length, $$array_ref[0],$$array_ref[1],$$array_ref[2],$$array_ref[10], $$array_ref[3], $$array_ref[4] . "\n";
		printf OUTFILE '%-10s %-10s %-15s %-15s %-16s %-15s %.1f %-8s', "Reverse", $rev_primer_length, $$array_ref[5],$$array_ref[6],$$array_ref[7],$$array_ref[10], $$array_ref[8], $$array_ref[9] . "\n\n";
	}	
}

$writer->endTag();

# This subroutine picks strings from DNA sequence which could be potential forward & reverse primer pairs.
# Intention is to pick substrings ending with "G" in case of forward primers; ending with "C" in case of reverse primers.

#Subroutine call & parameters used.
#&pickSubstrings("fwd", \@mod_seq, $length, \%forward_primers);
#&pickSubstrings("rev", \@mod_seq, $length, \%reverse_primers);

sub pickSubstrings
{
	my $type = $_[0];
	my $ref_seq = $_[1];
	my $primer_length = $_[2];
	my $ref_hash = $_[3];
 	
 	my @seq = @$ref_seq;
 
 	for(my $start=0; $start <= $#seq - $primer_length + 1; $start++)
 	{
 		my $end = ($start + $primer_length) - 1;

 		if($type eq "rev")
 		{ 			
 			my @oligo_ntd = ();
 			my $oligo_ntd = "";
 			@oligo_ntd = @seq[$start..$end]; 
 			$oligo_ntd = join("", @oligo_ntd);
			
			my $num_g = 0;
			$num_g += () = $oligo_ntd =~ /(G)/g;

 			
 		 	# Now consider only substrings ending with "C", having atmost 1 "G".
	
 			if(($oligo_ntd[$#oligo_ntd] eq "C") && ($num_g <=1))
 			{
				&checkNumCpG($oligo_ntd, $start, $end, $ref_hash);
 			}	
 		}	
 		else
 		{ 			
 			my @oligo_ntd = ();
 			my $oligo_ntd = "";
 			
 			@oligo_ntd = @seq[$start..$end];
 			$oligo_ntd = join("", @oligo_ntd);
			
 			my $num_g = 0;
			$num_g += () = $oligo_ntd =~ /(G)/g;	
			
			if(($oligo_ntd[$#oligo_ntd] eq "G") && ($oligo_ntd[$#oligo_ntd] ne "C"))
 			{
 				&checkNumCpG($oligo_ntd, $start,$end, $ref_hash);
 			}	
 		}
 	}	
}
 
# This sub-routine checks mainly for number of CpG's, Tm. 
# Call and parameters passed to checkNumCpG :

#&checkNumCpG($oligo_ntd, $start, $end, $ref_hash);

sub checkNumCpG
{
 	my $oligo_ntd = $_[0];
 	my $start = $_[1];
 	my $end = $_[2];
 	my $ref_hash = $_[3];
 	
 	# Determining number of CpG's in the primer.
 	# Primer with CpG <= 1 is desired.
 	my $num_cpg = 0;
 	
 	$num_cpg += () = $oligo_ntd =~ /(CG)/g;

 	# If num_cpg is less than or equal to 1, then calculate Tm of the primer.
 	if($num_cpg <= 1)
 	{
 		my $Tm = &calculateTm(\$oligo_ntd);

 		if(($Tm >= $lower_Tm) && ($Tm <= $upper_Tm))
 		{
 			my @array = ($end, $oligo_ntd, $Tm);
 			push(@{$ref_hash->{$start}},\@array);
 		}
 	}	
}

#Tm calculations according to Santa Lucia 1998; Owczarzy salt correction; IDT oligoanalyzer Tm calculations 
  
sub calculateTm
{
  my $ref_primer = $_[0];
  
  my $primer = $$ref_primer;
	my $comp_primer = $primer;
  $comp_primer =~ tr/ACGT/TGCA/;
		
	my @primer = split("", $primer);
	my @comp = split ("", $comp_primer);
		
	my $num_gc = 0;
		
	$num_gc += () = $primer =~ /(G|C)/g;
	my $fraction_gc = ($num_gc)/length($primer);
		
	# Tm below is calculated using nearest neighbor formula
	my $Tm = 0;
	my $R = 1.987;
	my $enthalpy = 0;
	my $entropy = 0;
	my $entropy_init = 0;
	my $enthalpy_init = 0;
			
	my $log_primer_conc = log($primer_conc)/log(2.718);
	my $log_salt_conc = log($salt_conc)/log(10);
		
	my $num_AA_TT = 0;
	my $num_AC_TG = 0;
	my $num_AG_TC = 0;
	my $num_AT_TA = 0;
	
	my $num_TA_AT = 0;
	my $num_TC_AG = 0;
	my $num_TG_AC = 0;
	my $num_TT_AA = 0;
		
	my $num_CA_GT = 0;
	my $num_CC_GG = 0;
	my $num_CG_GC = 0;
	my $num_CT_GA = 0;
		
	my $num_GA_CT = 0;
	my $num_GC_CG = 0;
	my $num_GG_CC = 0;
	my $num_GT_CA = 0;
		
		
	for(my $i=0; $i<$#primer; $i++)
	{
		if((($primer[$i].$primer[$i+1]) =~ m/AA/) && (($comp[$i].$comp[$i+1]) =~ m/TT/))
		{
			$num_AA_TT++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/AC/) && (($comp[$i].$comp[$i+1]) =~ m/TG/))
		{
			$num_AC_TG++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/AG/) && (($comp[$i].$comp[$i+1]) =~ m/TC/))
		{
			$num_AG_TC++;
		}	
		if((($primer[$i].$primer[$i+1]) =~ m/AT/) && (($comp[$i].$comp[$i+1]) =~ m/TA/))
		{
			$num_AT_TA++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/CA/) && (($comp[$i].$comp[$i+1]) =~ m/GT/))
		{
			$num_CA_GT++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/CC/) && (($comp[$i].$comp[$i+1]) =~ m/GG/))
		{
			$num_CC_GG++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/CG/) && (($comp[$i].$comp[$i+1]) =~ m/GC/))
		{
			$num_CG_GC++;
		}		
		if((($primer[$i].$primer[$i+1]) =~ m/CT/) && (($comp[$i].$comp[$i+1]) =~ m/GA/))
		{
			$num_CT_GA++;
		}	
		if((($primer[$i].$primer[$i+1]) =~ m/GA/) && (($comp[$i].$comp[$i+1]) =~ m/CT/))
		{
			$num_GA_CT++;
		}		
		if((($primer[$i].$primer[$i+1]) =~ m/GC/) && (($comp[$i].$comp[$i+1]) =~ m/CG/))
		{
			$num_GC_CG++;
		}		
		if((($primer[$i].$primer[$i+1]) =~ m/GG/) && (($comp[$i].$comp[$i+1]) =~ m/CC/))
		{
			$num_GG_CC++;
		}		
		if((($primer[$i].$primer[$i+1]) =~ m/GT/) && (($comp[$i].$comp[$i+1]) =~ m/CA/))
		{
			$num_GT_CA++;
		}		
		if((($primer[$i].$primer[$i+1]) =~ m/TA/) && (($comp[$i].$comp[$i+1]) =~ m/AT/))
		{
			$num_TA_AT++;
		}
		if((($primer[$i].$primer[$i+1]) =~ m/TC/) && (($comp[$i].$comp[$i+1]) =~ m/AG/))
		{
			$num_TC_AG++;
		}	
		if((($primer[$i].$primer[$i+1]) =~ m/TG/) && (($comp[$i].$comp[$i+1]) =~ m/AC/))
		{
			$num_TG_AC++;
		}	
		if((($primer[$i].$primer[$i+1]) =~ m/TT/) && (($comp[$i].$comp[$i+1]) =~ m/AA/))
		{
			$num_TT_AA++;
		}		
	}
		
	if((($primer[0]) =~ m/G/) && (($comp[0]) =~ m/C/))
	{
		$entropy_init += -2.8;
		$enthalpy_init += 0.1;
	}
	if((($primer[$#primer]) =~ m/G/) && (($comp[$#comp]) =~ m/C/))
	{
		$entropy_init += -2.8;
		$enthalpy_init += 0.1;
	}
	if((($primer[0]) =~ m/C/) && (($comp[0]) =~ m/G/))
	{
		$entropy_init += -2.8;
		$enthalpy_init += 0.1;
	}
	if((($primer[$#primer]) =~ m/C/) && (($comp[$#comp]) =~ m/G/))
	{
		$entropy_init += -2.8;
		$enthalpy_init += 0.1;
	}
	if((($primer[0]) =~ m/A/) && (($comp[0]) =~ m/T/))
	{
		$entropy_init += 4.1;
		$enthalpy_init += 2.3;
	}
	if((($primer[$#primer]) =~ m/A/) && (($comp[$#comp]) =~ m/T/))
	{
		$entropy_init += 4.1;
		$enthalpy_init += 2.3;
	}
	if((($primer[0]) =~ m/T/) && (($comp[0]) =~ m/A/))
	{
		$entropy_init += 4.1;
		$enthalpy_init += 2.3;
	}
	if((($primer[$#primer]) =~ m/T/) && (($comp[$#comp]) =~ m/A/))
	{
		$entropy_init += 4.1;
		$enthalpy_init += 2.3;
	}
		
		
	$enthalpy = ($num_AA_TT * (-7.9)) + 
							($num_AC_TG * (-8.4)) + 
							($num_AG_TC * (-7.8)) + 
							($num_AT_TA * (-7.2)) + 
							($num_CA_GT * (-8.5)) + 
							($num_CC_GG * (-8.0)) + 
							($num_CG_GC * (-10.6)) + 
							($num_CT_GA * (-7.8)) + 
							($num_GA_CT * (-8.2)) + 
							($num_GC_CG * (-9.8)) + 
							($num_GG_CC * (-8.0)) + 
							($num_GT_CA * (-8.4)) + 
							($num_TA_AT * (-7.2)) +
							($num_TC_AG * (-8.2)) + 
							($num_TG_AC * (-8.5)) + 
							($num_TT_AA * (-7.9));
		 
	$entropy = 	($num_AA_TT * (-22.2)) + 
							($num_AC_TG * (-22.4)) + 
							($num_AG_TC * (-21.0)) + 
							($num_AT_TA * (-20.4)) + 
							($num_CA_GT * (-22.7)) + 
							($num_CC_GG * (-19.9)) + 
							($num_CG_GC * (-27.2)) + 
							($num_CT_GA * (-21.0)) + 
							($num_GA_CT * (-22.2)) + 
							($num_GC_CG * (-24.4)) + 
							($num_GG_CC * (-19.9)) + 
							($num_GT_CA * (-22.4)) + 
							($num_TA_AT * (-21.3)) +
							($num_TC_AG * (-22.2)) + 
							($num_TG_AC * (-22.7)) + 
							($num_TT_AA * (-22.2));
		
	$enthalpy = ($enthalpy + $enthalpy_init) * 1000;
	
	my $num_phosphates = $#primer; # this is correct without ambiguity (ref. Santa Lucia 1998)
		
	$entropy = ($entropy_init + $entropy) + (0.368 * ($num_phosphates) * (log($salt_conc)/log(2.718)));
		
	$Tm = ($enthalpy/($entropy + ($R * $log_primer_conc))) - 273.15;
	
	my $salt_Tm = 0;
		
	$salt_Tm = (1/$Tm) + (((4.29 * $fraction_gc - 3.95) * ($log_salt_conc) + (0.94 * ($log_salt_conc ** 2))) * (10 ** -5));
	$salt_Tm = 1/$salt_Tm;
		
	return "$salt_Tm";
}
 
 
# This subroutine takes the start points of potential primer substrings and extends them to the given product length.
# &checkProduct("fwd",\%forward_primers, \@mod_seq, \%fwd_product);
#	&checkProduct("rev",\%reverse_primers, \@rev_comp_seq, \%rev_product);
sub checkProduct
{
	my $type = $_[0]; 
 	my $ref_primer = $_[1]; 
 	my $ref_seq = $_[2]; 
 	my $ref_product = $_[3]; 
 	
 	my @seq = @$ref_seq; 
 	my $start_point = 0;
 	my $end_point = 0; 
 
	foreach my $i (keys %$ref_primer)
 	{
 		if($type eq "rev")
 		{
			$start_point = $i;
 			
 			$end_point = ($start_point + $optimum_product_size) - 1;
 				
 			# Determining number of CpG's in the product.
			my $num_cpg = 0; 
 			if($end_point <= $#seq)
 			{	
 				$num_cpg = $rev_array_num_cpg[$end_point] - $rev_array_num_cpg[$start_point];
 			} 			
 			else
 			{
 				next;
 			}	
 		
 			# If Product with CpG >= 6 is desired.Uncomment the below condition  
 				
 			#if($num_cpg > 6)
 			#{
 				my @product_values = ($end_point,$num_cpg);
 					
 				# Populating reverse product hash, key=start point, value=array of (end-point, primer endpoints, Tm, num_CpGs).
 				$ref_product->{$start_point} = \@product_values;
 			#}
 		}	
 		else
 		{
 			$start_point = $i;
 			$end_point = $start_point + $optimum_product_size - 1;
			my $num_cpg = 0;
 			
 			# Determining number of CpG's in the product.
 			if($end_point <= $#seq)
 			{	
				$num_cpg = $fwd_array_num_cpg[$end_point] - $fwd_array_num_cpg[$start_point];
			}
 			else
 			{
 				next;
 			}
 			# If product with CpG >= 6 is desired, uncomment the below if condition
 				
 			#if($num_cpg > 6)
 			#{
 				my @product_values = ($end_point, $num_cpg);
 				$ref_product->{$start_point} = \@product_values;
 			#}
 		}	 			
 	}	
}	

# This subroutine checks for overlap between forward and reverse products got thru extn of fwd and rev primers.
#	&checkOverlap(\%fwd_product, \%rev_product, \%forward_primers, \%reverse_primers, \%primer_pairs);

sub checkOverlap
{
	my $href_fwd_product = $_[0]; 
 	my $href_rev_product = $_[1]; 
 	my $href_fwd_primer = $_[2]; 
 	my $href_rev_primer = $_[3]; 
 	my $href_primer_pairs = $_[4];
 	
 	foreach my $fwd_primer_start(keys %$href_fwd_primer)
 	{
 		if(exists $href_fwd_product->{$fwd_primer_start}) # Checks to see if fwd primer and pdt start points are same.
 		{
 			my $fwd_pdt_end = ${$href_fwd_product->{$fwd_primer_start}}[0]; #if(exists $href_fwd_product->{$fwd_primer_start}); # gets end point of the fwd product.
 			
 			if(exists ($href_rev_primer->{$#seq-$fwd_pdt_end}) && ($href_rev_product->{$#seq-$fwd_pdt_end})) 
 			{
 				for(my $i=0;$i<=$#{$href_fwd_primer->{$fwd_primer_start}}; $i++)
 				{
 					my $fwd_primer_end = ${${$href_fwd_primer->{$fwd_primer_start}}[$i]}[0];        
					my $fwd_primer = ${${$href_fwd_primer->{$fwd_primer_start}}[$i]}[1];            
 					my $fwd_primer_Tm = ${${$href_fwd_primer->{$fwd_primer_start}}[$i]}[2];
 					my $fwd_pdt_cpg = ${$href_fwd_product->{$fwd_primer_start}}[1];
 				
 					my $fwd_primer_value = &checkCpGIndex($fwd_primer);	

 					for(my $j=0; $j<=$#{$href_rev_primer->{$#seq-$fwd_pdt_end}}; $j++)
 					{
 						my $rev_primer_end = ${${$href_rev_primer->{$#seq-$fwd_pdt_end}}[$j]}[0];        
						my $rev_primer = ${${$href_rev_primer->{$#seq-$fwd_pdt_end}}[$j]}[1];    
						my $rev_primer_Tm = ${${$href_rev_primer->{$#seq-$fwd_pdt_end}}[$j]}[2];
						my $rev_pdt_cpg = ${$href_rev_product->{$#seq-$fwd_pdt_end}}[1];
						
						my $diff = $fwd_primer_Tm - $rev_primer_Tm;
						 							
						if(abs($diff) <= $max_Tm_difference)
						{						
						 	my $rev_primer_value = &checkCpGIndex($rev_primer);
						 	
						 	if(($fwd_primer_value == 1) && ($rev_primer_value == 1))
						 	{
								my @fwd_primer_values = ($fwd_primer_start, $fwd_primer_end, $fwd_primer, $fwd_primer_Tm, $fwd_pdt_cpg);
								my @rev_primer_values = ($#seq-$fwd_pdt_end,$rev_primer_end, $rev_primer, $rev_primer_Tm, $rev_pdt_cpg);

								my @primers = (\@fwd_primer_values, \@rev_primer_values);
															
 								push(@{$href_primer_pairs->{$fwd_primer_start}}, \@primers); 
 							}
 						}	
 					}	
 				}	
 			}
 		}
 	}
}	

## mod by hunter
## check at most 1 CpG in the first 1/3 of primer
sub checkCpGIndex
{
	my $primer = $_[0];
 
 	my $num_cpg = 0;
 	my $index = 0;
 	my $char = "CG";
 	
 	$index = index($primer, $char);
 	$num_cpg = 1 if($index != -1);
 	
    if ($allow_cpg_in_primer){
        if($num_cpg == 1)
        {
            if($index < int(length($primer)/3))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }	
        elsif($num_cpg == 0)
        {
            return 1; 
        }
    }else{
        if($num_cpg>0){
            return 0;
        }else{
            return 1;
        }
    }
}

sub checkSelfAnnealing
{
	my $primer = $_[0];
 	
 	my @primer = split("", $primer);	
 	
 	my $match = 0;
 	my $mismatch = 0;
 		
 	for(my $j=0; $j<= int($#primer/2); $j++)
 	{
 		#my $i = 0;
 		if(($primer[$j] eq "A") && ($primer[$#primer-$j] eq "T"))
 		{
 			$match++; 
 		}
 		elsif(($primer[$j] eq "T") && ($primer[$#primer-$j] eq "A"))
 		{
 			$match++;
 		}
 		elsif(($primer[$j] eq "G") && ($primer[$#primer-$j] eq "C"))
 		{
 			$match++; 
 		}
 		elsif(($primer[$j] eq "C") && ($primer[$#primer-$j] eq "G"))
 		{
 			$match++; 
 		}
 		else
 		{
 			$mismatch++;
 		}
	}
 			
 	#Match > 3 - discard that primer.	This indicates probability of hairpin formation.		
 	if($match >= $max_base_complements)
 	{
 		return 0; 
 	}
 	else
 	{
 		return 1;
 	}
}

sub pickNonRedundantPrimers
{
	my $href_primer_pairs = $_[0];
	my $href_uniq_primer_pairs = $_[1];
	
	foreach my $key(sort{$a <=> $b} keys %$href_primer_pairs)
 	{ 
 		if(exists ($href_uniq_primer_pairs->{$key-1}) || ($href_uniq_primer_pairs->{$key-2}) || ($href_uniq_primer_pairs->{$key-3})) 
 		{
 			next;
 		}	
 		else
 		{
 			$href_uniq_primer_pairs->{$key} = $href_primer_pairs->{$key}; 
 		}
 	}	
}
